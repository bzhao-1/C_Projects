/*
    Ben Zhao and Ntense Obono
    bits.c
    
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "bits.h"

void to_upper(char *s) {
    if(s == NULL) {
        return ;
    }
    while(*s != '\0') {
        if(islower(*s)) {
            *s = *s & ~(1 << 5);
        }
        s++;
    }
}

void to_lower(char *s) {
    if(s == NULL) {
        return ;
    }
    while(*s != '\0') {
        if(isupper(*s)) {
            *s = *s | (1 << 5);
        }
        s++;
    }
}

int middle_bits(int n, int bit_index, int bit_count) {
    int u = (unsigned int)n;
    if(bit_index < 0 || bit_index > 30 || bit_count < 1 || bit_count > (31 - bit_index)) {
        return (int)u;
    }

    int shift = u >> bit_index;
    int mask = (1 << bit_count) - 1;
    shift = shift & mask;

    return shift;
}

bool to_utf8(int codepoint, char *utf8_buffer) {
    if(utf8_buffer == NULL || codepoint < 0 || codepoint > 0x10FFFF) {
        return false;

    }

    if(codepoint >= 0x0000 && codepoint <= 0x007F) {
        utf8_buffer[0] = (char) codepoint;
        utf8_buffer[1] = 0x00;
        return true;
    }
    else if(codepoint >= 0x0080 && codepoint <= 0x07FF) {
        int middleBits = middle_bits(codepoint, 6, 5);
        utf8_buffer[0] = (char) (0xC0 | middleBits);
        middleBits = middle_bits(codepoint, 0, 6);
        utf8_buffer[1] = (char) (0x80 | middleBits);
        utf8_buffer[2] = '\0';
        return true;
    }
    else if(codepoint >= 0x0800 && codepoint <= 0xFFFF) {
        int middleBits = middle_bits(codepoint, 12, 4);
        utf8_buffer[0] = (char) (0xE0 | middleBits);
        middleBits = middle_bits(codepoint, 6, 6);
        utf8_buffer[1] = (char) (0x80 | middleBits);
        middleBits = middle_bits(codepoint, 0, 6);
        utf8_buffer[2] = (char) (0x80 | middleBits);
        utf8_buffer[3] = '\0';
        return true;
    }
    else if(codepoint >= 0x010000 && codepoint <= 0x10ffff) {
        int middleBits = middle_bits(codepoint, 18, 3);
        utf8_buffer[0] = (char) (0xF0 | middleBits);
        middleBits = middle_bits(codepoint, 12, 6);
        utf8_buffer[1] = (char) (0x80 | middleBits);
        middleBits = middle_bits(codepoint, 6, 6);
        utf8_buffer[2] = (char) (0x80 | middleBits);
        middleBits = middle_bits(codepoint, 0, 6);
        utf8_buffer[3] = (char) (0x80 | middleBits);
        utf8_buffer[4] = '\0';
        return true;
    }


    return false;
}

int from_utf8(char *utf8_buffer) {
    if(utf8_buffer == NULL){
        return -1;
    }
    // one byte
    if((utf8_buffer[0] & 0x80) == 0x00){
        return utf8_buffer[0];
    }
    // 2 bytes
    else if((utf8_buffer[0] & 0xE0) == 0xC0){
        int left_bits = utf8_buffer[0] & 0x1F;
        int right_bits = utf8_buffer[1] & 0x3F;
        int codepoint = (left_bits << 6)|right_bits;
        return codepoint;
    }
    // 3 bytes
    else if((utf8_buffer[0] & 0xF0) == 0xE0){
        int left_bits = utf8_buffer[0] & 0x0F;
        int right_bits_one = utf8_buffer[1] & 0x3F;
        int right_bits_two = utf8_buffer[2] & 0x3F;
        int codepoint = ((left_bits << 12)|(right_bits_one << 6)|right_bits_two);
        return codepoint;
    }
    // 4 bytes
    else if((utf8_buffer[0] & 0xF0) == 0xF0){
    int left_bits = utf8_buffer[0] & 0x7;
    int right_bits_one = utf8_buffer[1] & 0x3F;
    int right_bits_two = utf8_buffer[2] & 0x3F;
    int right_bits_three = utf8_buffer[3] & 0x3F;
    int codepoint = (((left_bits << 18)|right_bits_one)<<6|right_bits_two)<<6|right_bits_three;
    return codepoint;
}

    return -1;
}

int main() {
    int codepoint = 0xE9;
    char utf8_string[10];
    if (to_utf8(codepoint, utf8_string)) {
        printf("UTF8 result: %s\n", utf8_string);
        printf("Individual bytes:\n");
        for (int k = 0; utf8_string[k] != '\0'; k++) {
            printf("  0x%02X\n", ((int)utf8_string[k]) & 0xFF);
        }
    }
  
    
}