/*
    depunctuate.c
    Ben Zhao, March 27 2023

    The program will copy the contents of inputfile to outputfile unchanged except that only digits (ASCII 48-57), tabs and spaces (9, 32), newlines (10, 13) and letters (65-90 uppercase, 97-122 lowercase) will be written to the output file.
*/


#include <stdio.h>
#include <ctype.h>


void print_usage_statement(const char *program_name);
void filter_file(const char * input_file_name, const char * output_file_name);


int main(int argc, char *argv[]) {
    // Parse the command line
    if (argc != 3) {
        print_usage_statement(argv[0]);
    }
    const char *input_file_name = argv[1];
    const char *output_file_name = argv[2];

    filter_file(input_file_name, output_file_name);

    return 0;
}

void print_usage_statement(const char *program_name) {
    fprintf(stderr, "Usage: %s inputfile outputfile\n", program_name);
    fprintf(stderr, "  prints to standard output the number of chars\n");
    fprintf(stderr, "  (as a decimal integer) in the specified file\n");
}

void filter_file(const char * input_file_name, const char * output_file_name) {
    FILE *input_file = fopen(input_file_name, "r");
    FILE *output_file = fopen(output_file_name, "w");

    if (input_file == NULL) {
        fprintf(stderr, "Input file does not exist");
    }
    
    char prev = '\n';
    char ch = fgetc(input_file);

    while (ch != EOF) {
        //Checking for only characters that match our requirements
        if (isdigit(ch) || isspace(ch) || isalpha(ch) || isupper(ch)) {
            fputc(ch, output_file);
            prev = ch;
        } 
        //New line characters
        else if (ch == '\n') {
            //If previous character is not also a newline, create a newline
            if (prev != '\n') {
                fputc('\n', output_file);
                prev = ch;
            }
        }
        //Non requirment matching character not added to output, set prev to current
        else{
            prev = ch;
        }

        ch = fgetc(input_file);
    }

    if (ferror(input_file)) {
        fprintf(stderr, "Error reading input file.\n");
        fclose(input_file);
        fclose(output_file);
    }

    // Clean up after ourselves.
    fclose(input_file);
    fclose(output_file);
}
