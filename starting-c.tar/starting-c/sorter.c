/*
    sorter.c

	Ben Zhao, 29 March 2023

    The program will read the lines of the text file into an array, sort them lexicographically (i.e. using the return value of strcmp as the comparison function)
    , and print the sorted list to standard output. Whats interesting is that all uppercase letters come before lowercase lexicographically. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ROW_COUNT 500
#define MAX_COLUMN_COUNT 201

int fill_grid(char grid[][MAX_COLUMN_COUNT], int column_count, const char * input_file_name);
void swap_rows(char grid[][MAX_COLUMN_COUNT], int row_index_1, int row_index_2, int column_count);
void print_grid(char grid[][MAX_COLUMN_COUNT], int row_count, int column_count, FILE *output_stream);
void insertion_sort(char grid[][MAX_COLUMN_COUNT], int row_count, int column_count);


int main(int argc, char *argv[]) {
    char grid[MAX_ROW_COUNT][MAX_COLUMN_COUNT];
    int column_count = 30;

    const char *input_file_name = argv[1];

    int row_count = fill_grid(grid, MAX_COLUMN_COUNT, input_file_name);

    insertion_sort(grid, row_count, column_count);

    print_grid(grid, row_count, column_count, stdout);
    return 0;
}


int fill_grid(char grid[][MAX_COLUMN_COUNT], int column_count, const char * input_file_name) {
    FILE *input = fopen(input_file_name, "r");

    if (input == NULL) {
        fprintf(stderr, "Input file does not exist");
    }
    
    int row = 0;
    while ((fgets(grid[row], MAX_COLUMN_COUNT, input) != NULL)) {
        // fprintf(stderr, "Words in row %d: %s\n", row, grid[row]);
        row++;
    }

    return row;

}

// Swaps the contents of the specified rows in the grid (only swapping column data
// up to the specified column count).
void swap_rows(char grid[][MAX_COLUMN_COUNT], int row_index_1, int row_index_2, int column_count) {
    for (int column = 0; column < column_count; column++) {
        char saved_char = grid[row_index_1][column];
        grid[row_index_1][column] = grid[row_index_2][column];
        grid[row_index_2][column] = saved_char;
    }
}

void insertion_sort(char grid[][MAX_COLUMN_COUNT], int row_count, int column_count) {
    // Compare key to each previous row that occurs before it in the grid array
    char key[MAX_COLUMN_COUNT];
 
    for (int i = 1; i < row_count; i++) {
        int j = i - 1;
        // Learned from C standard libraries, allows you to copy over contents from ith row in grid to key 
        strcpy(key, grid[i]);

        // Swap jth row and j+1th row only if in bounds and word in jth row comes after word in key var 
        while (j >= 0 && strcmp(grid[j], key) > 0) {
            swap_rows(grid, j+1, j, column_count);
            j--;
        }
        i = j+1;
    }

}

// Prints the contents of the grid (only printing data stored in the specified
// range of rows and columns).
void print_grid(char grid[][MAX_COLUMN_COUNT], int row_count, int column_count, FILE *output_stream) {
    for (int row = 0; row < row_count; row++) {
        fprintf(output_stream, "%s", grid[row]);
    }
}
