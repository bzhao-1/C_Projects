/*
    Ben Zhao and Ntense Obono April 2023
    This function takes into two integer parameters, a and b,
    and returns an integer that represents the smaller of the two integer parameter values(second if equal).
*/

int function1(int a, int b) {
    int res = a;
    if (b > a) {
        return res;
    } else {
        res = b;
        return res;
    }
}