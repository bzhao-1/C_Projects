/*
    Ben Zhao and Ntense Obono April 2023
    This puzzle utilizes the comparison functon from puzzle 1 and returns the smallest integer
    between 3 integer parameters by comparing the third parameter with the smallest of the first two(using the first function).
*/

int function1(int a, int b) {
    int res = a;
    if (b > a) {
        return res;
    } else {
        res = b;
        return res;
    }
}

int function2(int a, int b, int c) {
    int res2 = c;
    int res = function1(a, b);
    a = res;
    b = res2;
    return function1(a, b);


}