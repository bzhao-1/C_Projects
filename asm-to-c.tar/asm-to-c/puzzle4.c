/*
    Ben Zhao and Ntense Obono April 2023
    This function recursively returns the nth fibonnaci number with the input "a" 
    specifying the nth number to return in the sequence(starting with 0th number as 0).
*/

int function1(int a){
    if (a <= 0){
        return 0;
    }
    
    int result = a;
    if (a == 1){
        return a;
    }
    result = function1(a-1);
    result += function1(a-2);


    return result;

}