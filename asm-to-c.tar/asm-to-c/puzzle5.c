/*
    Ben Zhao and Ntense Obono April 2023
    This function iteratively returns the nth fibonnaci number with the input "a" 
    specifying the nth number to return in the sequence(starting with 0th number as 0).
*/

int function1(int a){
    if (a <= 0){
        return 0;
    }
    int prev = 0;
    int first = 1;
    int curr = 1;
    while(curr < a){
        int temp = prev;
        prev = first;
        first += temp;
        curr += 1;

    }
    return first;

}