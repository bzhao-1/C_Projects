/*
    Ben Zhao and Ntense Obono April 2023
    This function takes two long parameters, a and b, and copies
    the contents at the location in memory pointed to by b into the location in memory pointed by "a"
    then adds a null terminator at end of "a".
*/

void function1(long a, long b){
    if ((a == 0) || (b == 0)) {
        return;
    }

    while (*((char*) b) != 0) {
        *((char*) a) = *((char*) b);
        a++;
        b++;
    }

    *((char*) a) = 0;
    return;

}