/*
    Ben Zhao and Ntense Obono April 2023
    This function returns the absolute value of an integer.
*/

int function1(int a) {
    int res = a;
    if (a < 0) {
        res = -res;
    } 
    return res;
}