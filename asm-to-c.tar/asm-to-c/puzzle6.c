/*
    Ben Zhao and Ntense Obono April 2023
    This function implements insertion sort on an array of n elements. 
*/


void function1(int *arr, int n) {
    int i = 1;
    while (i < n) {
        int j = i;
        int curr = arr[i];
        while (j > 0 && arr[j - 1] > curr) {
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = curr;
        i++;
    }
}