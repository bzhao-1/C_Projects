#include <stdio.h>
#include <string.h>

int main() {
    unsigned char bytes[] = {0xA8, 0xC3, 0x68, 0x43};
    unsigned char bytes2[] = {0x4D, 0x20, 0x65, 0x72, 0xA8, 0xC3, 0x68, 0x43};
    
    float f;
    memcpy(&f, bytes, sizeof(float));
    printf("The real number interpretation of the bytes is: %f\n", f);


    int i;
    memcpy(&i, bytes, sizeof(int));
    printf("The decimal integer interpretation of the bytes is: %d\n", i);

    long l;
    memcpy(&l, bytes2, sizeof(long));
    printf("The long decimal number interpretation of the bytes is: %ld\n", l);

    return 0;
}