#include <stdio.h>

int main() {
    float x = 0.0 / 0.0;  
    printf("%f\n", x);   
    return 0;
}